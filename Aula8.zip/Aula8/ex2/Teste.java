package ex2;

import java.util.Scanner;

public class Teste {
    public static void main (String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Insira um nome: ");
        String n = sc.nextLine();
        System.out.println("Insira um sobrenome: ");
        String s = sc.nextLine();
        System.out.println("Insira um cpf: ");
        String c = sc.nextLine();
        PessoaFisica p1 = new PessoaFisica(n, s, c);
        System.out.println(p1.dados());
        PessoaFisica p2 = new PessoaFisica();
        System.out.println(p2.dados());
        PessoaFisica p3 = new PessoaFisica();
        p3.setNome("Claudio");
        p3.setSobrenome("Manuel");
        p3.setCpf("1001");
        System.out.println(p3.dados());
        Desempregado d = new Desempregado("-", "-0", "0", 7000);
        System.out.println(d.dados());
        Empregado e1 = new Empregado("A","A1","1");
        System.out.println(e1.dados());
        Empregado e2 = new Mensalista("B","B1","2", 1000);
        System.out.println(e2.dados());
        Empregado e3 = new Comissionado("C","C1","3", 1100, 500);
        System.out.println(e3.dados());
        Empregado e4 = new Horista("D","D1","4", 30);
        System.out.println(e4.dados());
        Empregado e5 = new Tarefeiro("E","E1","5", 700);
        System.out.println(e5.dados());
        Empregado e6 = new Vendedor("F","F1","6", 5000);
        System.out.println(e6.dados());

        sc.close();
    }
}
