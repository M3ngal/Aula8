package ex2;

public class Tarefeiro extends Empregado{
    private double pagamento;

    public Tarefeiro(String nome, String sobrenome, String cpf, double pagamento) {
        super(nome, sobrenome, cpf);
        this.pagamento = pagamento;
    }

    public double salario(){
        return this.pagamento;
    }
}
