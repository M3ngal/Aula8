package ex2;

public class Vendedor extends Empregado{
    private double lucro;

    public Vendedor(String nome, String sobrenome, String cpf, double lucro) {
        super(nome, sobrenome, cpf);
        this.lucro = lucro;
    }

    public double salario(){
        return this.lucro;
    }
}
