package ex1;

public class Boleto extends Pagamento{
    private String numeroDoBoleto;
    private int diav;
    private int mesv;
    private int anov;

    public Boleto(String nomeDoPagador , String cpf, double valorASerPago, String numeroDoBoleto, int diav, int mesv, int anov){
        super(nomeDoPagador, cpf, valorASerPago);
        this.numeroDoBoleto = numeroDoBoleto;
        this.diav = diav;
        this.mesv = mesv;
        this.anov = anov;
    }

    public String getNumeroDoBoleto(){
        return numeroDoBoleto;
    }
    public int getDiav(){
        return diav;
    }
    public int getMesv(){
        return mesv;
    }
    public int getAnov(){
        return anov;
    }


    public  void setNumeroDoBoleto(String numeroDoBoleto){
        this.numeroDoBoleto = numeroDoBoleto;
    }
    public  void setDiav(int diav){
        this.diav = diav;
    }
    public  void setMesv(int mesv){
        this.mesv = mesv;
    }
    public  void setAnov(int anov){
        this.anov = anov;
    }

}
